package com.example.mediafinder;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;

import java.util.List;

/**
 * Created by thevs on 3/1/2018.
 */

public class CatItemsAdapter extends RecyclerView.Adapter {

    String[] list;

    CatItemsAdapter(String[] arr){
        list = arr;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.cat_items, parent, false);
        CatViewHolder holder = new CatViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {    }

    @Override
    public int getItemCount() {
        return 0;
    }
}
